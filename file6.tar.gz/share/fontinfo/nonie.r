.fp \np nr
.lg 0
.tr `'
