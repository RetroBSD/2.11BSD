.fp \np tR
.lg 0
