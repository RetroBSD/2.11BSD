.fp \np tr
.lg 0
