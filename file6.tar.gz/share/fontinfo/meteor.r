.fp \np mr
.lg 0
.tr `'
