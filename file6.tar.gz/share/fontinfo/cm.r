.fp \np cr
.lg 0
