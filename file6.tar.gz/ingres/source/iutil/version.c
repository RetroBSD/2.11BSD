# include	"../version.h"

/*
**  VERSION.C -- define the current version
**
**	This just factors out the current version into one file
**	to make releases easier.
*/

char	Version[] =	VERSION;
char	Rel_date[] =	REL_DATE;
char	Mod_date[] =	MOD_DATE;
