#
/*
**	COPYRIGHT
**
**	The Regents of the University of California
**
**	1977
**
**	This program material is the property of the
**	Regents of the University of California and
**	may not be reproduced or disclosed without
**	the prior written permission of the owner.
*/


/*
**	VERSION is the version number of this incarnation of INGRES, in
**		the form 9.9/99, where the number after the slash is
**		the release, mod number, or whatever.  The info before
**		the slash is used for determining the file names for
**		the dayfile and proctab, and the whole thing is printed
**		out at login time.
*/

# define	VERSION		"6.3/0"		/* version number */
# define	REL_DATE	"February 1, 1981"	/* release date */
# define	MOD_DATE	"February 1, 1981"	/* modification date */
