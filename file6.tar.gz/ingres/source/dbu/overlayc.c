extern	copy();
extern	save();

int	(*Func[])() =
{
	&copy,
	&save,
};
